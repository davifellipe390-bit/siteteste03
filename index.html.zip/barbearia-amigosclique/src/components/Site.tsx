import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";

export const WHATSAPP = "556194119355";

export function SiteShell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background text-foreground font-body">
      <header className="border-b-2 border-dashed border-border">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-4">
          <Link to="/" className="font-display text-2xl text-primary">AmigosClique</Link>
          <nav className="flex gap-5 text-sm uppercase tracking-widest">
            <Link to="/" className="hover:text-primary" activeOptions={{ exact: true }} activeProps={{ className: "text-primary" }}>Início</Link>
            <Link to="/agendamento" className="hover:text-primary" activeProps={{ className: "text-primary" }}>Agendar</Link>
          </nav>
        </div>
      </header>
      {children}
      <footer className="border-t-2 border-dashed border-border py-8 text-center text-sm text-muted-foreground">
        SCLRN 715, Bloco D, Loja 57 — Asa Norte, Brasília - DF · (61) 3347-3710
      </footer>
    </div>
  );
}
