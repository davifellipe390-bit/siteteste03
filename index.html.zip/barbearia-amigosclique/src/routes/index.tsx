import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteShell } from "@/components/Site";
import hero from "@/assets/barbearia.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Barbearia AmigosClique — Asa Norte, Brasília" },
      { name: "description", content: "Corte clássico e atendimento direto na Asa Norte. Nota 4.7 com 330 avaliações." },
      { property: "og:title", content: "Barbearia AmigosClique — Asa Norte, Brasília" },
      { property: "og:description", content: "Corte clássico e atendimento direto na Asa Norte." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const horarios = [
  ["Segunda a sexta", "8h às 19h"],
  ["Sábado", "8h às 18h"],
  ["Domingo", "Fechado"],
];

function Index() {
  return (
    <SiteShell>
      <section className="relative">
        <img src={hero} alt="Interior da Barbearia AmigosClique" className="h-[70vh] w-full object-cover sepia-[.35]" />
        <div className="absolute inset-0 bg-overlay" />
        <div className="absolute inset-0 flex flex-col items-center justify-center px-5 text-center text-hero-foreground">
          <p className="uppercase tracking-[0.3em] text-sm">Desde sempre na Asa Norte</p>
          <h1 className="font-display mt-3 text-5xl md:text-7xl">Barbearia AmigosClique</h1>
          <p className="mt-4 max-w-xl text-lg">Frequentada por moradores da região que valorizam um corte clássico e um atendimento direto.</p>
          <Link to="/agendamento" className="mt-8 rounded-sm border-2 border-accent bg-accent px-8 py-3 font-semibold uppercase tracking-widest text-accent-foreground hover:bg-transparent hover:text-hero-foreground">Agendar horário</Link>
        </div>
      </section>

      <section className="mx-auto grid max-w-5xl gap-6 px-5 py-16 md:grid-cols-3">
        <div className="rustic-card">
          <h2 className="font-display text-2xl text-primary">Avaliação</h2>
          <p className="mt-3 text-5xl font-display">4.7<span className="text-xl text-muted-foreground">/5</span></p>
          <p className="text-accent text-xl">★★★★★</p>
          <p className="text-muted-foreground">Com base em 330 avaliações</p>
        </div>
        <div className="rustic-card">
          <h2 className="font-display text-2xl text-primary">Horários</h2>
          <ul className="mt-3 space-y-2">
            {horarios.map(([d, h]) => (
              <li key={d} className="flex justify-between border-b border-dashed border-border pb-1"><span>{d}</span><span className="font-semibold">{h}</span></li>
            ))}
          </ul>
        </div>
        <div className="rustic-card">
          <h2 className="font-display text-2xl text-primary">Onde estamos</h2>
          <p className="mt-3">SCLRN 715, Bloco D, Loja 57<br />Asa Norte, Brasília - DF</p>
          <a href="tel:+556133473710" className="mt-3 block font-semibold text-primary">(61) 3347-3710</a>
        </div>
      </section>
    </SiteShell>
  );
}
