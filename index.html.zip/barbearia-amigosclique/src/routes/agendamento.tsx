import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteShell, WHATSAPP } from "@/components/Site";

export const Route = createFileRoute("/agendamento")({
  head: () => ({
    meta: [
      { title: "Agendar horário — Barbearia AmigosClique" },
      { name: "description", content: "Agende seu corte na Barbearia AmigosClique e confirme direto pelo WhatsApp." },
      { property: "og:title", content: "Agendar horário — Barbearia AmigosClique" },
      { property: "og:description", content: "Agende seu corte e confirme pelo WhatsApp." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Agendamento,
});

const servicos = ["Corte clássico", "Barba", "Corte + Barba", "Pezinho / acabamento"];

function horariosDoDia(data: string) {
  if (!data) return [];
  const dia = new Date(data + "T12:00").getDay();
  if (dia === 0) return [];
  const fim = dia === 6 ? 18 : 19;
  const lista: string[] = [];
  for (let h = 8; h < fim; h++) lista.push(`${h}:00`, `${h}:30`);
  return lista;
}

function Agendamento() {
  const [f, setF] = useState({ nome: "", servico: servicos[0], data: "", hora: "", obs: "" });
  const horas = horariosDoDia(f.data);
  const domingo = f.data && horas.length === 0;
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setF({ ...f, [k]: e.target.value, ...(k === "data" ? { hora: "" } : {}) });

  function enviar(e: React.FormEvent) {
    e.preventDefault();
    const dataBR = f.data.split("-").reverse().join("/");
    const msg = `Olá, Barbearia AmigosClique! Gostaria de agendar um horário.\n\n*Nome:* ${f.nome}\n*Serviço:* ${f.servico}\n*Data:* ${dataBR}\n*Horário:* ${f.hora}${f.obs ? `\n*Observação:* ${f.obs}` : ""}\n\nAguardo a confirmação. Obrigado!`;
    window.open(`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(msg)}`, "_blank");
  }

  const hoje = new Date().toISOString().slice(0, 10);
  return (
    <SiteShell>
      <main className="mx-auto max-w-xl px-5 py-14">
        <h1 className="font-display text-4xl text-primary text-center">Agende seu horário</h1>
        <p className="mt-2 text-center text-muted-foreground">Preencha abaixo e a mensagem vai pronta para o nosso WhatsApp.</p>
        <form onSubmit={enviar} className="rustic-card mt-8 space-y-4">
          <label className="block">Seu nome<input required value={f.nome} onChange={set("nome")} className="rustic-input" /></label>
          <label className="block">Serviço
            <select value={f.servico} onChange={set("servico")} className="rustic-input">{servicos.map((s) => <option key={s}>{s}</option>)}</select>
          </label>
          <label className="block">Data<input required type="date" min={hoje} value={f.data} onChange={set("data")} className="rustic-input" /></label>
          {domingo && <p className="text-destructive">Domingo estamos fechados. Escolha outro dia.</p>}
          <label className="block">Horário
            <select required value={f.hora} onChange={set("hora")} disabled={!horas.length} className="rustic-input">
              <option value="">Selecione</option>{horas.map((h) => <option key={h}>{h}</option>)}
            </select>
          </label>
          <label className="block">Observação (opcional)<textarea value={f.obs} onChange={set("obs")} rows={3} className="rustic-input" /></label>
          <button disabled={!!domingo} className="w-full rounded-sm bg-whatsapp py-3 font-semibold uppercase tracking-widest text-whatsapp-foreground hover:opacity-90 disabled:opacity-50">Enviar pelo WhatsApp</button>
        </form>
      </main>
    </SiteShell>
  );
}
